/**
 * Dec 12, 2014
 */
package org.apache.hadoop.mapreduce.lib.output;

import java.io.DataOutputStream;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat.LineRecordWriter;

/**
 * @author lin
 *
 */
public final class MyLineRecordWriter<K,V> extends LineRecordWriter<K, V> {
    public MyLineRecordWriter(DataOutputStream out,String split) {
        super(out,split);
    }

}
