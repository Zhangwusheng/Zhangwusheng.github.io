package com.aipai.bigdata.etl.util;
import com.aipai.bigdata.etl.Constants;

public class ConnectionPoolFactory {

    public static ConnectionPool createConnectionPool(Configuration conf) {
        String dbuser = conf.get(Constants.JDBC_USER);
        if (dbuser == null) {
            throw new IllegalArgumentException("Message out db user is null.");
        }

        String dbpassword = conf.get(Constants.JDBC_PASSWORD);
        if (dbpassword == null) {
            throw new IllegalArgumentException("Message out db password is null.");
        }

        String url = conf.get(Constants.JDBC_URL);
        if (url == null) {
            throw new IllegalArgumentException("Message out db url is null.");
        }

        int poolSize = conf.getInt(Constants.JDBC_POOL_SIZE, 1);

        JdbcConn jdbc = new JdbcConn();
        jdbc.setUrl(url);
        jdbc.setUsername(dbuser);
        jdbc.setPassword(dbpassword);

        ConnectionPool conn = new ConnectionPool(jdbc, poolSize);

        return conn;
    }
}
