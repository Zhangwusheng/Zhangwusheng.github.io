/**
 * Dec 12, 2014
 */
package com.aipai.bigdata.etl.util;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.UUID;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
/**
 * @author lin
 *
 */
public final class IOUtils {
    private static final Log log = LogFactory.getLog(IOUtils.class);

    private IOUtils() {
    }

    public static void close(Object obj) {
        if (obj == null) {
            return;
        }
        if (obj instanceof Closeable) {
            try {
                ((Closeable) obj).close();
            } catch (IOException e) {
                log.error("ioerr in close", e);
            }
            return;
        } else if (obj instanceof Statement){
            try{
                ((Statement)obj).close();
            } catch (SQLException e) {
                log.error("sqlerr in closing statement", e);
            }
            return;
        } else if (obj instanceof Connection) {
            try {
                ((Connection) obj).close();
            } catch (Exception e) {
            }
            return;
        } else if (obj instanceof PreparedStatement) {
            try {
                ((PreparedStatement) obj).close();
            } catch (Exception e) {
            }
            return;
        }
        throw new IllegalArgumentException("unsupported close obj:" + obj.getClass());
        /*else if (obj instanceof Statement)
            throw new UnsupportedOperationException("unsupported:" + obj.getClass().getName());
            */
    }

    public static Path genUniqDir(Path base, String day, String hour, Configuration conf, int tryMax) throws IOException {
        FileSystem fs = base.getFileSystem(conf);
        for (int i = 0; i < tryMax; i++) {
            String time = StringUtils.timeSimpleString(System.currentTimeMillis());
            Path dir = new Path(base, String.format("%s%s/%s_%d_%s_%d", day, hour, StringUtils.HOST, StringUtils.PID, time, UUID.randomUUID()
                    .getMostSignificantBits()));
            if (fs.exists(dir)) {
                log.warn(String.format("dir exists in try#{%d}:%s", i, dir));
                continue;
            } else {
                return dir;
            }

        }
        throw new IOException(String.format("failed to gen dir in %s after trys %d", base, tryMax));
    }

    public static String getClazzLocation(Class<?> clazz) throws IOException {
        String path = clazz.getProtectionDomain().getCodeSource().getLocation().getFile();
        return path;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(getClazzLocation(FileSystem.class));
    }

    public static long copyBytes(InputStream in, OutputStream out, int buffSize) throws IOException {
        byte buf[] = new byte[buffSize];
        long total = 0;
        int bytesRead = in.read(buf);
        while (bytesRead >= 0) {
            total += bytesRead;
            out.write(buf, 0, bytesRead);
            bytesRead = in.read(buf);
        }
        return total;
    }

    public static Map<String, String> readProperties(InputStream in) throws IOException {
        Properties prop = new Properties();
        prop.load(in);
        Map<String, String> r = new HashMap<String, String>();
        Set<Entry<Object, Object>> entries = prop.entrySet();
        for (Entry<Object, Object> en : entries) {
            if (en.getKey() != null && en.getValue() != null) {
                r.put(en.getKey().toString(), en.getValue().toString());
            }
        }
        return r;
    }

    public static Map<String, String> readProperties(File filePath) throws IOException {
        return readProperties(new FileInputStream(filePath));
    }

    public static Map<String, String> readProperties(String file) throws IOException {
        return readProperties(new File(file));
    }
}
