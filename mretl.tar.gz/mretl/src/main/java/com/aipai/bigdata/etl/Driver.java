package com.aipai.bigdata.etl;

//import org.apache.hadoop.hdfs.DistributedFileSystem;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.conf.Configuration;

/**
 * Created by zws on 6/29/15.
 */
public class Driver {

    public static void main(String[] args) {

        try
        {
            Configuration conf = new Configuration();
            FileSystem fs = FileSystem.get(conf);
//            BaseMR bm = null;
        }
        catch (java.io.IOException e)
        {
            System.out.print(e.getStackTrace());
        }
        System.out.printf("");
    }
}
