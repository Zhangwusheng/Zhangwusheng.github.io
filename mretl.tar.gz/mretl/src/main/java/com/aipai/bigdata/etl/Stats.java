package com.aipai.bigdata.etl;

public interface Stats {
    Stats merge(Stats s);
}
