package com.aipai.bigdata.etl;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;

public class NotifierFactory {

    public static Notify createNotifierFactory(Configuration conf, String notifierName) throws ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        String className = conf.get(notifierName);
        if (className == null)
            return null;
        Class c = Class.forName(className);
        Notify n = (Notify) c.newInstance();
        n.init(conf);
        return n;
    }
    
    public static List<Notify> createNotifierFactory(Configuration conf) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String classes = conf.get("notifiers.class.list");
        if(classes == null)
            return null;
        List<Notify> list =new LinkedList<Notify>();
        for( String clazz : Arrays.asList(classes.split(","))){
            Class c = Class.forName(clazz);
            Notify n = (Notify) c.newInstance();
            n.init(conf);
            list.add(n);
        }
        return list;
    }
}
