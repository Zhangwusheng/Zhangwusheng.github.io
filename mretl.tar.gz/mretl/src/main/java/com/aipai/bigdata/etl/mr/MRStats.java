/**
 * Dec 12, 2014
 */
package com.aipai.bigdata.etl.mr;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import com.aipai.bigdata.etl.Stats;
import com.aipai.bigdata.etl.util.JsonUtils;

//import com.hiido.mretl.Stats;
//import com.hiido.mretl.utils.JsonUtils;

/**
 * @author lin
 *
 */
public final class MRStats implements Stats{
    
    private static final String m_m = "m";
    private static final String m_uf = "uf";
    private static final String m_i= "i";
    
    private final Map<String, SucessAndFailed> m = new TreeMap<String, SucessAndFailed>();
    private long unknowFailed;
    private long sucess;
    private long failed;
    private final Map<String, LongWrapper> ignored = new TreeMap<String, LongWrapper>();
    private long totalIgnored;

    public MRStats(){
    }
    
    
    public MRStats(MRStats s){
        for(Entry<String, SucessAndFailed>sf:s.m.entrySet()){
            m.put(sf.getKey(), sf.getValue().copy());
        }
        for(Entry<String,LongWrapper> lw:s.ignored.entrySet()){
            ignored.put(lw.getKey(), lw.getValue().copy());
        }
        this.unknowFailed = s.unknowFailed;
        this.sucess = s.sucess;
        this.failed = s.failed;
        this.totalIgnored = s.totalIgnored;
    }
    
    public Map<String,SFI> sfi(){
        Map<String,SFI> map = new HashMap<String, SFI>();
        for(Entry<String, SucessAndFailed> e:m.entrySet()){
            map.put(e.getKey(), new SFI(e.getValue().getSucess(),e.getValue().getFailed()));
        }
        
       for(Entry<String, LongWrapper> i:ignored.entrySet()){
           String act = i.getKey();
           long ignored  = i.getValue().v;
           SFI sfi = map.get(act);
           if(sfi==null){
               sfi = new SFI();
               map.put(act, sfi);
           }
           sfi.ignored = ignored;
       }
       return map;
    }
    @Override
    public String toString() {
        if (total() == 0) {
            return "empty statis";
        }
        StringBuilder sb = new StringBuilder(512);
        sb.append(String.format("%d/%d=%d,unknow=%d,ignored=%d\n", sucess, total(), sucess * 10000 / total(), unknowFailed, totalIgnored));
        sb.append("####detail####\n");
        for (Entry<String, SucessAndFailed> e : m.entrySet()) {
            sb.append(e.getKey()).append(":").append(e.getValue()).append("\n");
        }
        sb.append("****ignored****\n");
        for (Entry<String, LongWrapper> e : ignored.entrySet()) {
            sb.append(e.getKey()).append(":").append(e.getValue().v).append("\n");
        }
        return sb.toString();
    }

    public void ignored(String act, long i) {
        totalIgnored += i;
        LongWrapper l = ignored.get(act);
        if(l==null){
            l = new LongWrapper();
            ignored.put(act,l);
        }
        l.v+=i;
    }

    public void sucess(String key, long s) {
        SucessAndFailed sf = m.get(key);
        if (sf == null) {
            sf = new SucessAndFailed();
            m.put(key, sf);
        }
        sf.addSucess(s);
        sucess += s;
    }

    public void failed(String key, long f) {
        SucessAndFailed sf = m.get(key);
        if (sf == null) {
            sf = new SucessAndFailed();
            m.put(key, sf);
        }
        sf.addFailed(f);
        failed += f;
    }

    public void addUnknowFailed(long f) {
        unknowFailed += f;
        failed += f;
    }
    
    public long total() {
        return sucess + failed + totalIgnored;
    }

    public long getFailed() {
        return failed;
    }

    public long getSucess() {
        return sucess;
    }

    public long getUnknowFailed() {
        return unknowFailed;
    }
    
    public long getTotalIgnored() {
        return totalIgnored;
    }

    public void setTotalIgnored(long totalIgnored) {
        this.totalIgnored = totalIgnored;
    }

    public Map<String, SucessAndFailed> getM() {
        return m;
    }

    public void setUnknowFailed(long unknowFailed) {
        this.unknowFailed = unknowFailed;
    }

    public void setSucess(long sucess) {
        this.sucess = sucess;
    }

    public void setFailed(long failed) {
        this.failed = failed;
    }

    
    public Map<String, LongWrapper> getIgnored() {
        return ignored;
    }
    
    public void setM(Map<String, SucessAndFailed> m) {
        this.m.putAll(m);
    }

    public void setIgnored(Map<String, LongWrapper> ignored) {
        this.ignored.putAll(ignored);
    }

    @Override
    public MRStats merge(Stats s) {
        MRStats mr = (MRStats)s;
        MRStats stats = new MRStats(this);
        for(Entry<String, SucessAndFailed>sf:mr.m.entrySet()){
            stats.sucess(sf.getKey(), sf.getValue().getSucess());
            stats.failed(sf.getKey(), sf.getValue().getFailed());
        }
        for(Entry<String,LongWrapper> lw:mr.ignored.entrySet()){
            stats.ignored(lw.getKey(), lw.getValue().v);
        }
        stats.addUnknowFailed(mr.unknowFailed);
        return stats;
    }

    
    public static void main(String[] args) throws Exception{
        MRStats s  = new MRStats();
        s.addUnknowFailed(1);
        s.sucess("a", 10);
        s.ignored("b", 2);
        String json = JsonUtils.pack(s);
        System.out.println(json);
        
        MRStats j = JsonUtils.parse(json, MRStats.class);
        System.out.println(j);
    }
}
