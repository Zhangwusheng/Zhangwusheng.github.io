/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.mr;

import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.NotifierFactory;
import com.aipai.bigdata.etl.Notify;
import com.aipai.bigdata.etl.io.CombineLineSmallFileInputFormat;
import com.aipai.bigdata.etl.io.KeyAsPathLineFileoutputFormat;
import com.aipai.bigdata.etl.util.FileLock;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.Trash;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.io.File;
import java.io.IOException;
import java.util.*;
import com.aipai.bigdata.etl.util.StringUtils;
import com.aipai.bigdata.etl.util.IOUtils;
//import com.hiido.mretl.Constants;
//import com.hiido.mretl.NotifierFactory;
//import com.hiido.mretl.Notify;
//import com.hiido.mretl.mr.io.CombineLineSmallFileInputFormat;
//import com.hiido.mretl.mr.io.KeyAsPathLineFileoutputFormat;
//import com.hiido.mretl.utils.FileLock;
//import com.hiido.mretl.utils.IOUtils;
//import com.hiido.mretl.utils.StringUtils;

/**
 * @author lin
 *
 */
public abstract class BaseMR extends Configured implements Tool {
    public static final String LOCK_DIR = "lock";
    public static final String MARK_DIR = "mark";

    protected static final Log log = LogFactory.getLog(BaseMR.class);
    protected String inBasePath;
    protected String inPath;

    protected String outBasePath;
    protected Path outPath;
    protected boolean cleanOut;

    protected String resultBasePath;

    protected String day;
    protected String hour;

    protected int redNum;

    protected final Map<String, String> dirMapping = new TreeMap<String, String>();

    protected boolean overwrite;
    protected boolean notifyNoOverwrite;
    protected boolean notify;

    protected boolean lock;
    protected FileLock filelock;

    protected boolean skipMark;

    protected final Map<String, Integer> actParts = new TreeMap<String, Integer>();

    protected final Set<String> cleaned = new HashSet<String>();
    protected final Set<String> notOverwrite = new HashSet<String>();
    
    private List<Notify> notifiers;
    
    protected BaseMR() {
        super(new Configuration());
        getConf().addResource("conf.xml");
        try {
            notifiers = NotifierFactory.createNotifierFactory(getConf());
        } catch (Throwable e) {
            log.error("failed to load notifiers from conf.xml", e);
            System.exit(1);
        }
    }

    protected abstract String dirMappingKey();

    protected abstract String actPartsKey();

    protected abstract String name();

    protected abstract void initInPath(Configuration conf, String day, String hour) throws Exception;

    protected abstract void initOutPath(Configuration conf, String day, String hour) throws Exception;

    protected abstract int redNum(Configuration conf);


    protected void initDirMapping(Configuration conf) throws Exception {
        Collection<String> map = conf.getStringCollection(dirMappingKey());
        for (String str : map) {
            String[] strs = str.split("=");
            if (strs.length != 2) {
                throw new IllegalArgumentException("require dir mapping format key=val:" + str);
            }
            dirMapping.put(strs[0].trim(), strs[1].trim());
        }
    }

    public static Map<String, Integer> parseActParts(Configuration conf, String key) {
        Collection<String> map = conf.getStringCollection(key);
        Map<String, Integer> ret = new HashMap<String, Integer>(map.size() * 8);
        for (String str : map) {
            String[] strs = str.split("=");
            if (strs.length != 2) {
                throw new IllegalArgumentException("require act parts format key=val:" + str);
            }
            ret.put(strs[0].trim(), Integer.valueOf(strs[1].trim()));
        }
        return ret;
    }

    public static Set<String> parseSet(Configuration conf, String key) {
        Collection<String> strs = conf.getStringCollection(key);
        Set<String> set = new HashSet<String>(strs.size() * 8);
        set.addAll(strs);
        return set;
    }

    protected void initActParts(Configuration conf) throws Exception {
        String partsKey = actPartsKey();
        String val = conf.get(partsKey);
        this.actParts.putAll(parseActParts(conf, partsKey));
        if (val != null) {
            conf.set(TextKeyPartitioner.KEY_PARTS_NUM, val);
        }
    }

    protected void initResultBasePath(Configuration conf) throws Exception {
        this.resultBasePath = conf.get(Constants.ETL_KEY_RESULT_BASE_PATH, Constants.DEF_ETL_RESULT_BASE_PATH);
    }

    protected void init(Configuration conf, String[] args) throws Exception {
        overwrite = conf.getBoolean(Constants.ETL_KEY_OVERWRITE, true);
        notifyNoOverwrite = conf.getBoolean(Constants.ETL_KEY_NOTIFY_NO_OVERWRITE, true);
        notify = conf.getBoolean(Constants.ETL_KEY_NOTIFY, true);

        lock = conf.getBoolean(Constants.ETL_KEY_LOCK, true);
        skipMark = conf.getBoolean(Constants.ETL_KEY_SKIP_MARK, false);
        cleanOut = conf.getBoolean(Constants.ETL_KEY_CLEAN_TMP_OUT, true);

        day = conf.get(Constants.ETL_KEY_DAY);
        hour = conf.get(Constants.ETL_KEY_HOUR);
        redNum = redNum(conf);
        //TODO
        //        day = "20141215";
        //        hour = "13";
        //        redNum = 1;

        StringUtils.assertNotEmpty(day, Constants.ETL_KEY_DAY);
        StringUtils.assertNotEmpty(hour, Constants.ETL_KEY_HOUR);

        initInPath(conf, day, hour);
        initOutPath(conf, day, hour);
        initResultBasePath(conf);
        StringUtils.assertNotEmpty(resultBasePath, "resultBasePath");

        initDirMapping(conf);
        initActParts(conf);
        log.info(String.format("%s:in=%s,out=%s,result base=%s,overwrite=%b,notify:%b,notifyNoOverwrite:%b", day + hour, inPath, outPath, resultBasePath, overwrite, notify,
                notifyNoOverwrite));
        log.info(String.format("lock=%b, skipMark=%b,redNum=%d,cleanOut=%b", lock, skipMark, redNum, cleanOut));
        log.info("dirMapping=" + dirMapping);
        log.info("actParts=" + actParts);
    }

    protected String resultDir(String base, String day, String act) {
        String to = dirMapping.containsKey(act) ? dirMapping.get(act) : act;
        return String.format("%s/%s/%s/%s", base, to, day.substring(0, 6), day.substring(6));
    }

    private boolean needRename(FileSystem fs, Path todir) throws IOException {
        String p = todir.toUri().getPath();
        if (notOverwrite.contains(p)) {
            log.info("ToDir is not overwrite:" + p);
            return false;
        }
        if (cleaned.contains(p)) {
            log.info("ToDir is cleaned:" + p);
            return true;
        }
        List<Path> olds = new ArrayList<Path>();
        FileStatus[] hours = fs.listStatus(todir);
        if (hours != null) {
            for (FileStatus h : hours) {
                if (h.getPath().getName().startsWith(hour + ".")) {
                    olds.add(h.getPath());
                }
            }
        }
        if (olds.isEmpty()) {
            log.info("not found old files in " + p);
            cleaned.add(p);
            return true;
        }

        if (overwrite) {
            for (Path old : olds) {
                if (!fs.delete(old, false) && fs.exists(old)) {
                    throw new IOException("failed to rm old file:" + old);
                }
                log.info("clean old file:" + old);
            }
            cleaned.add(p);
            return true;
        } else {
            notOverwrite.add(p);
            log.info("not overwrite,but found old files:" + olds);
            return false;
        }
    }

    protected boolean renameResult() throws Exception {
        log.info("begin to rename result");
        Configuration conf = getConf();
        FileSystem fs = outPath.getFileSystem(conf);
        FileStatus[] files = fs.listStatus(outPath);
        if (files == null) {
            throw new IOException("not find any children in " + outPath);
        }
        boolean all = true;

        for (FileStatus file : files) {
            String name = file.getPath().getName();
            if (file.isDir()) {
                if (!name.startsWith("_")) {
                    log.error("should not have dir in " + outPath);
                }
                continue;
            }
            if (name.startsWith("_")) {
                log.info("ignored file:" + name);
                continue;
            }
            final int lastidx = name.lastIndexOf('.');

            String exten = "";
            String act = name;
            String pnum = null;
            if (lastidx != -1) {
                act = name.substring(0, lastidx);
                exten = name.substring(lastidx);
            }
            final int partIdx = act.indexOf(Constants.PARTS_SPLIT);
            if (partIdx != -1) {
                final String pending = act;
                act = pending.substring(0, partIdx);
                pnum = pending.substring(partIdx + 1);
                if (!StringUtils.isNum(pnum)) {
                    log.error("fatal:illegal file:" + file.getPath());
                    continue;
                }
            }
            try {
                Path dir = new Path(resultDir(resultBasePath, day, act));
                if (!fs.exists(dir)) {
                    fs.mkdirs(dir);
                }
                if (!needRename(fs, dir)) {
                    log.info("not need rename to dir:" + dir);
                    continue;
                }
                Path to = null;
                if (pnum == null) {
                    to = new Path(dir, hour + ".log" + exten);
                } else {
                    to = new Path(dir, hour + "." + pnum + ".log" + exten);
                }
                if (fs.rename(file.getPath(), to)) {
                    log.info(String.format("sucess to rename %s=>%s", file.getPath(), to));
                    notify(act, file.getPath(), true);
                } else {
                    log.error(String.format("failed to rename %s=>%s", file.getPath(), to));
                    notify(act, file.getPath(), false);
                    all = false;
                }
            } catch (Exception e) {
                log.error(String.format("failed to rename %s:%s", act, file.getPath()), e);
                all = false;
            }
        }
        return all;
    }

    protected void mark() {
        File mark = markFile();
        try {
            mark.getParentFile().mkdirs();
            mark.createNewFile();
        } catch (IOException e) {
            log.error("failed to mark:" + mark.getAbsolutePath());
        }
    }

    protected void notify(String act, Path path, boolean success) {
        if (!notify){
            log.info("Completed without notify.");
            return;
        }
        for(Notify n : notifiers)
            n.notify(act, path.toUri().getPath(), success);
    }

    protected void initJob(Job job) throws IOException {
        job.setNumReduceTasks(redNum);
    }

    protected boolean startable() {
        if (!skipMark) {
            File mark = markFile();
            if (mark.exists()) {
                log.info("mark exists:" + mark);
                return false;
            } else {
                log.info("mark not exists:" + mark);
            }
        }
        return lock();
    }

    protected boolean lock() {
        if (!lock) {
            return true;
        }

        if (this.filelock == null) {
            File lFile = lockFile();
            lFile.deleteOnExit();
            this.filelock = new FileLock(lFile);
        }
        try {
            boolean locked = filelock.tryLock();
            log.info(String.format("lock file[%b]:%s", locked, filelock.file()));
            return locked;
        } catch (Exception e) {
            log.error("failed to lock:" + filelock.file(), e);
            return false;
        }
    }

    protected void closeLock() {
        IOUtils.close(filelock);
    }

    protected String getTag() {
        return String.format("%s/%s%s", name(), day, hour);
    }

    protected File lockFile() {
        return new File(LOCK_DIR, getTag());
    }

    protected File markFile() {
        return new File(MARK_DIR, getTag());
    }

    protected int runInit(String[] args, Class<? extends Mapper> m, Class<? extends Reducer> r) throws Exception {
        log.info(String.format("Mapper=[%s],Reducer=[%s]", m.getName(), r.getName()));
        Configuration conf = getConf();
//        Job job = new Job(conf, name());
        Job job = Job.getInstance(conf,name());

        init(job.getConfiguration(), args);
        job.setJarByClass(this.getClass());

        //set the InputFormat of the job to our InputFormat
        job.setInputFormatClass(CombineLineSmallFileInputFormat.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        job.setMapperClass(m);
        job.setReducerClass(r);
        job.setPartitionerClass(TextKeyPartitioner.class);
        job.setOutputFormatClass(KeyAsPathLineFileoutputFormat.class);
        initJob(job);

        FileInputFormat.addInputPaths(job, inPath);
        FileOutputFormat.setOutputPath(job, outPath);

        if (!startable()) {
            log.info("could no start after check");
            return 1;
        }
        log.info("begin to run mr");
        return job.waitForCompletion(true) ? 0 : 1;
    }

    public static void runMain(String[] args, BaseMR mr) {
        log.info("args:" + Arrays.asList(args));
        try {
            int ret = ToolRunner.run(mr, args);
            if (ret != 0) {
                log.error("failed run mr:ret code=" + ret);
                System.exit(ret);
            } else {
                log.info("sucess run mr");
            }
            if (mr.renameResult()) {
                mr.mark();
                //
            } else {
                //TODO has some rename failed,need to check
            }
            mr.clean();
            System.exit(ret);
        } catch (Throwable e) {
            log.error("failed to run", e);
            System.exit(1);
        }
    }

    protected void clean() {
        if(notifiers != null){
            for(Notify n : notifiers)
                n.close();
        }
        if (cleanOut) {
            log.info("begin to clean tmp out:" + outPath);
            try {
                Trash trash = new Trash(getConf());
                trash.moveToTrash(outPath);
                log.info("sucess to clean tmp out");
            } catch (Exception e) {
                log.error("failed to clean tmp out", e);
            }
        }
    }

    public static void main(String[] args) {
        Configuration.addDefaultResource("conf.xml");
        System.out.println(parseActParts(new Configuration(), "etl.ylog.parts"));
    }
}
