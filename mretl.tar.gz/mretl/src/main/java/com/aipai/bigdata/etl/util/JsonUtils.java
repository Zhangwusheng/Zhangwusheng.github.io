package com.aipai.bigdata.etl.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

/**
 * @mail mylinyuzhi@gmail.com
 * @date Feb 10, 2014 6:03:16 PM
 */
public final class JsonUtils {

    private static final ThreadLocal<ObjectMapper> mapper = new ThreadLocal<ObjectMapper>() {
        @Override
        protected ObjectMapper initialValue() {
            return new ObjectMapper();
        }
    };

    private JsonUtils() {
    }

    public static ObjectMapper jsonMapper() {
        return mapper.get();
    }

    public static <T> T parse(String json, Class<? extends T> clazz) {
        try {
            return jsonMapper().readValue(json, clazz);
        } catch (Throwable e) {
            throw new IllegalArgumentException(String.format("faile to parse [%s] from [%s]", clazz.getName(), json), e);
        }
    }

    public static Map<String, Object> parseMap(String json, boolean assertHas) {
        Map<String, Object> map = null;
        try {
            map = jsonMapper().readValue(json, Map.class);
        } catch (Throwable e) {
            throw new IllegalArgumentException("failed to parse map from:" + json, e);
        }
        if (assertHas && (map == null || map.isEmpty())) {
            throw new IllegalArgumentException("parse the empty map from:" + json);
        }
        return map;
    }

    public static List<Object> parseList(String json, boolean assertHas) {
        List<Object> list = null;
        try {
            list = jsonMapper().readValue(json, List.class);
        } catch (Throwable e) {
            throw new IllegalArgumentException("failed to parse list from:" + json, e);
        }
        if (assertHas && (list == null || list.isEmpty())) {
            throw new IllegalArgumentException("parse the empty list from:" + json);
        }
        return list;
    }

    public static String pack(Object obj) {
        try {
            return jsonMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new IllegalArgumentException("faile to pack json string", e);
        }
    }

    public static void main(String[] args) throws Exception {
        Map<Integer, String> m = new HashMap<Integer, String>();
        m.put(1, "a");
        System.out.println(pack(m));
    }
}
