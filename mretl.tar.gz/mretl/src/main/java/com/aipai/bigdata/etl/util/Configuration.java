package com.aipai.bigdata.etl.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

//import com.hiido.live.common.utils.IOUtils;
//import com.hiido.live.common.utils.StringUtils;

public class Configuration {

    private final Map<String, String> objs = new ConcurrentHashMap<String, String>();

    public Configuration() {
    }

    public Configuration(Map<String, String> initConf) {
        this.objs.putAll(initConf);
    }

    public static Configuration createConfiguration(Map<Object, Object> conf) {
        Map<String, String> m = new HashMap<String, String>();
        for (Entry<Object, Object> e : conf.entrySet()) {
            if (e.getKey() != null && e.getValue() != null) {
                m.put(e.getKey().toString(), e.getValue().toString());
            }
        }
        return new Configuration(m);
    }
    
    public Map<String,String> toMap(){
        return new HashMap<String,String>(objs);
    }

    public static Configuration fromFile(String file) {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            Map pros = IOUtils.readProperties(fis);
            return createConfiguration(pros);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
//            IOUtils.closeIO(fis);
            IOUtils.close(fis);
        }

    }

    public String get(String key) {
        return getString(key);
    }

    public Configuration cloneConf() {
        Configuration r = new Configuration(objs);
        return r;
    }

    public Map<String, String> getObjs() {
        return objs;
    }

    public String getString(String key) {
        if (key == null) {
            return null;
        }
        return objs.get(key);
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        if (key == null) {
            return defaultValue;
        }
        String v = objs.get(key);
        if (v == null) {
            return defaultValue;
        }
        return Boolean.parseBoolean(v);
    }

    public String getString(String key, String defaultValue) {
        if (key == null) {
            return null;
        }
        String v = objs.get(key);
        return v == null ? defaultValue : v;
    }

    public int getInt(String key, int defaultValue) {
        String temp = objs.get(key);
        return temp == null ? defaultValue : Integer.valueOf(temp);
    }
    
    public float getFloat(String key,float defaultValue){
        String temp = objs.get(key);
        return temp == null ? defaultValue : Float.valueOf(temp);
    }

    public void put(String key, String value) {
        this.objs.put(key, value);
    }

    public String[] getStrings(String key) {
        return getStrings(key, ",");
    }

    public String[] getStrings(String key, String sep) {
        String s = getString(key);
        if (s == null) {
            return new String[0];
        }
        return StringUtils.split(s, sep);
    }

}
