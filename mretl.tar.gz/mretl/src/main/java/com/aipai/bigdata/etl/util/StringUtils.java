/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.util;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;

import com.aipai.bigdata.etl.Constants;

import java.util.StringTokenizer;

/**
 * @author lin
 */
public final class StringUtils {

    private static final Log log = LogFactory.getLog(StringUtils.class);
    public static final String UNKNOW_HOST = "unknow";
    public static final String HOST;
    public static final long PID;

    static {
        String host = UNKNOW_HOST;
        try {
            host = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.error("err in get host name", e);
        }
        HOST = host;

        String processName = java.lang.management.ManagementFactory.getRuntimeMXBean().getName();
        PID = Long.parseLong(processName.split("@")[0]);
    }

    private StringUtils() {
    }

    public static boolean isEmpty(String str) {
        if (str == null) {
            return true;
        }

        if ("".equals(str.trim())) {
            return true;
        }
        return false;
    }

    public static boolean emptyOrNull(String v) {
        return v == null || v.trim().isEmpty();
    }

    public static void assertNotEmpty(String v, String name) {
        if (emptyOrNull(v)) {
            throw new IllegalArgumentException("empty:" + name);
        }
    }

    public static void assertNoBlank(String v, String name) {
        if (v.contains(" ")) {
            throw new IllegalArgumentException("contain blank:" + name);
        }
    }

    public static String timeSimpleString(long time) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        return sdf.format(new Date(time));
    }

    public static String fileNameNotExtension(String file) {
        int idx = file.lastIndexOf('.');
        return idx == -1 ? file : file.substring(0, idx);
    }

    public static String fileExtension(String file) {
        int idx = file.lastIndexOf('.');
        return idx == -1 || idx == file.length() - 1 ? "" : file.substring(idx + 1, file.length());
    }

    public static String firstName(String fileName) {
        int idx = fileName.indexOf('.');
        return idx != -1 ? fileName.substring(0, idx) : fileName;
    }

    public static boolean isNum(String num) {
        try {
            Long.valueOf(num);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static List<URL> fileUrls(Collection<File> strs) throws IOException {
        List<URL> files = new ArrayList<URL>();
        for (File f : strs) {
            files.add(f.toURL());
        }
        return files;
    }

    public static List<File> files(Collection<String> strs) throws IOException {
        List<File> files = new ArrayList<File>();
        for (String str : strs) {
            files.add(new File(str));
        }
        return files;
    }

    public static void main(String[] args) throws Exception {
        String name = "web!1.gz";
        String exten = "";
        String act = name;
        String pnum = null;
        final int lastidx = name.lastIndexOf('.');
        if (lastidx != -1) {
            act = name.substring(0, lastidx);
            exten = name.substring(lastidx);
        }
        final int partIdx = act.indexOf(Constants.PARTS_SPLIT);
        if (partIdx != -1) {
            final String pending = act;
            act = pending.substring(0, partIdx);
            pnum = pending.substring(partIdx);
            if (!StringUtils.isNum(pnum)) {
                System.out.println("err");
            }
        }
    }

    public static String[] split(String str, String split) {
        List<String> strings = new ArrayList<String>(16);
        StringTokenizer token = new StringTokenizer(str, split, false);
        while (token.hasMoreElements()) {
            strings.add(token.nextToken());
        }
        String[] strArray = new String[strings.size()];
        return strings.toArray(strArray);
    }
}
