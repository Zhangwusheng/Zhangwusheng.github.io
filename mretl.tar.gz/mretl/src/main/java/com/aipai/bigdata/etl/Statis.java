package com.aipai.bigdata.etl;

import java.io.Closeable;

import org.apache.hadoop.conf.Configuration;
import com.aipai.bigdata.etl.util.ConnectionPool;


public interface Statis extends Closeable{
    void init(Configuration conf, ConnectionPool pool);
    void close();
    void start();
    void report(Stats stats);
}
