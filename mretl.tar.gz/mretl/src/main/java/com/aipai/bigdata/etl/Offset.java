/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import com.aipai.bigdata.etl.util.StringUtils;

/**
 * @author lin
 *
 */
public final class Offset implements WritableComparable {
    private long offset;
    private String fileName;
    //not contan extenstion
    private String name;

    public void readFields(DataInput in) throws IOException {
        this.offset = in.readLong();
        this.fileName = Text.readString(in);
        this.name = StringUtils.firstName(fileName);
    }

    public void write(DataOutput out) throws IOException {
        out.writeLong(offset);
        Text.writeString(out, fileName);
    }
    
    @Override
    public String toString(){
        return String.format("fname=%s,off=%d", fileName,offset);
    }

    public int compareTo(Object o) {
        Offset that = (Offset) o;

        int f = this.fileName.compareTo(that.fileName);
        if (f == 0) {
            return (int) Math.signum((double) (this.offset - that.offset));
        }
        return f;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Offset)
            return this.compareTo(obj) == 0;
        return false;
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }

    public String getFileName() {
        return fileName;
    }

    public String getName() {
        return name;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
        this.name = StringUtils.firstName(fileName);
    }


}
