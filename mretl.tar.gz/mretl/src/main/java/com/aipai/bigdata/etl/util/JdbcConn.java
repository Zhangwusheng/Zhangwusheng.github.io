package com.aipai.bigdata.etl.util;

import java.io.Closeable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//import com.hiido.live.common.utils.IOUtils;

public class JdbcConn implements Closeable {
    
    private String url = "";
    private String username = "";
    private String password = "";
    private String driverName = "com.mysql.jdbc.Driver";

    private Class<?> dirver;

    private Connection conn;
    private Statement stmt;

    public JdbcConn() {
    }
    
    @Override
    public String toString(){
        return url;
    }

    public Connection openConnection() throws SQLException {
        return openConnection(false);
    }

    public Connection openConnection(boolean newConn) throws SQLException {
        synchronized (this) {
            if (dirver == null) {
                try {
                    dirver = Class.forName(driverName);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
            if (!newConn) {
                if (conn == null) {
                    conn = DriverManager.getConnection(url, username, password);
                    // executeUpdate("set sql_mode = '';");
                }
                return conn;
            }
        }
        return DriverManager.getConnection(url, username, password);
    }

    public synchronized void close() {
//        IOUtils.closeIO(stmt);
        IOUtils.close(stmt);
        stmt = null;
//        IOUtils.closeIO(conn);
        IOUtils.close(conn);
        conn = null;
    }

    public boolean executeUpdate(String strSql) throws SQLException {
        // getConnection(_DRIVER,_URL,_USER_NA,_PASSWORD);
        if (stmt == null)
            stmt = conn.createStatement();
        return stmt.executeUpdate(strSql) > 0;

    }

    public ResultSet executeSql(String strSql) throws Exception {
        if (stmt == null)
            stmt = conn.createStatement();

        return stmt.executeQuery(strSql);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public static void main(String[] args) throws Exception {
        JdbcConn conn = new JdbcConn();
        conn.setDriverName("com.mysql.jdbc.Driver");
        conn.setUsername("root");
        conn.setPassword("123456");
        conn.setUrl("jdbc:mysql://localhost:3306/test");
        conn.openConnection();
        conn.executeUpdate("delete from student where name = 'guotianlian'");
        ResultSet rs = conn.executeSql("select * from student");
        while (rs.next()) {
            System.out.println(rs.getString("name"));
        }
        rs.close();
        conn.close();
        // String sql = "select * from students";
    }
}