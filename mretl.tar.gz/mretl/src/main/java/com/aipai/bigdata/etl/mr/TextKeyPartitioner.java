/**
 * Dec 31, 2014
 */
package com.aipai.bigdata.etl.mr;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.aipai.bigdata.etl.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;
import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.mr.BaseMR;

/**
 * @author lin
 *
 */
public final class TextKeyPartitioner<V> extends Partitioner<Text, V> implements Configurable {
    public static final String KEY_PARTS_NUM = "key.parts.num";
    private static final Log log = LogFactory.getLog(TextKeyPartitioner.class);

    private final Map<String, Integer> partsNum = new HashMap<String, Integer>();
    private Configuration conf;
    private int num = -1;
    private int remainNum;
    private int partUse;
    private Map<Text, Integer> partUseMap;

    @Override
    public void setConf(Configuration conf) {
        this.conf = conf;
        this.partsNum.putAll(com.aipai.bigdata.etl.mr.BaseMR.parseActParts(conf, KEY_PARTS_NUM));
        for (Integer i : partsNum.values()) {
            partUse += i;
        }
        this.partUseMap = new HashMap<Text, Integer>(partUse * 8);
        log.info("init parts num:" + partsNum);
    }

    @Override
    public Configuration getConf() {
        return conf;
    }

    @Override
    public int getPartition(Text key, V value, int numPartitions) {
        if (num == -1) {
            num = numPartitions;
            int alloc = numPartitions;
            for (Entry<String, Integer> e : partsNum.entrySet()) {
                String act = e.getKey();
                int n = e.getValue();
                for (int i = 0; i < n; i++) {
                    if(i==n-1){
                        partUseMap.put(new Text(act), --alloc);
                    }else{
                        partUseMap.put(new Text(act + Constants.PARTS_SPLIT + i), --alloc);    
                    }
                }
            }
            remainNum = num - partUse;
            log.info("act map:" + new TreeMap<Text, Integer>(partUseMap));
            log.info("remain parts num:" + remainNum);
        } else {
            if (num != numPartitions) {
                String err = String.format("init numPartitions[%d] != now[%d]", num, numPartitions);
                log.error(err);
                throw new IllegalStateException(err);
            }
        }
        if (remainNum > 0 && !partUseMap.isEmpty()) {
            Integer p = partUseMap.get(key);
            if (p != null) {
                return p;
            }
            return (key.hashCode() & Integer.MAX_VALUE) % remainNum;
        } else {
            return (key.hashCode() & Integer.MAX_VALUE) % numPartitions;
        }
    }

}
