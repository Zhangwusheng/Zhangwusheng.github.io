/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.mblog;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.mr.BaseMR;
import com.aipai.bigdata.etl.util.IOUtils;
import com.aipai.bigdata.etl.mr.BaseReducer;

/**
 * @author lin
 *
 */
public final class MblogMR extends BaseMR {

    @Override
    protected void initInPath(Configuration conf, String day, String hour) throws Exception {

        inBasePath = conf.get(Constants.ETL_KEY_MBLOG_INPUT_BASE_PATH, Constants.DEF_CLASSIFY_MBLOG_INPUT_BASE_PATH);
        inPath = String.format("%s/%s/%s", inBasePath, day, hour);
    }

    @Override
    protected void initOutPath(Configuration conf, String day, String hour) throws Exception {

        outBasePath = conf.get(Constants.ETL_KEY_MBLOG_OUTPUT_BASE_PATH, Constants.DEF_CLASSIFY_MBLOG_OUTPUT_BASE_PATH);
        outPath = IOUtils.genUniqDir(new Path(outBasePath), day, hour, conf, 10000);
    }

    @Override
    public int run(String[] args) throws Exception {
        return runInit(args, MblogMapper.class, BaseReducer.class);
    }

    public static void main(String[] args) {
        MblogMR mr = new MblogMR();
        runMain(args, mr);
    }

    @Override
    protected String dirMappingKey() {

        return Constants.ETL_KEY_MBLOG_MAPPING;
    }

    @Override
    protected String name() {
        return "mblog";
    }

    @Override
    protected String actPartsKey() {

        return Constants.ETL_KEY_MBLOG_PARTS;
    }

    @Override
    protected int redNum(Configuration conf) {
        return conf.getInt(Constants.ETL_KEY_YLOG_REDUCE_NUM, 192);
    }

}
