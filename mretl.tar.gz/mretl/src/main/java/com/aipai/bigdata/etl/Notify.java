package com.aipai.bigdata.etl;

import org.apache.hadoop.conf.Configuration;

public interface Notify {
    
    public void init(Configuration conf);
    
    public void notify(String act, String path, boolean success);
    
    public void close();
}
