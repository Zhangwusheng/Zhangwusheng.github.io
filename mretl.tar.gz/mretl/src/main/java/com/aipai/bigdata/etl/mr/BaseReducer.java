package com.aipai.bigdata.etl.mr;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.util.StringUtils;
import com.aipai.bigdata.etl.util.JsonUtils;
import com.aipai.bigdata.etl.util.ConnectionPool;
import com.aipai.bigdata.etl.util.ConnectionPoolBuilder;

public class BaseReducer extends Reducer<Text, Text, Text, Text> {
    protected static final Log log = LogFactory.getLog(BaseReducer.class);
    private MRStats s0;
    private MRStats s1;
    private boolean debug;

    private String day;
    private String hour;

    private boolean abort;
    
    private MRStats merge(MRStats s, String json) {
        MRStats j = JsonUtils.parse(json, MRStats.class);
        return s.merge(j);
    }

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        Configuration conf = context.getConfiguration();
        debug = conf.getBoolean(Constants.ETL_R_DUBUG, true);
        abort = conf.getBoolean(Constants.ETL_R_ABORT_REPORT, false);
        day = conf.get(Constants.ETL_KEY_DAY);
        hour = conf.get(Constants.ETL_KEY_HOUR);
        StringUtils.assertNotEmpty(day, Constants.ETL_KEY_DAY);
        StringUtils.assertNotEmpty(hour, Constants.ETL_KEY_HOUR);
        log.info(String.format("day=%s,hour=%s,debug=%b,abort=%b", day, hour, debug,abort));
    }

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        if (Constants.S0.equals(key)) {
            if (s0 == null) {
                s0 = new MRStats();
            }
            for (Text v : values) {
                if( debug ){
                    log.info("MMMM- before merge -------------------------------\n"+s0);
                    log.info("MMMM- v= -------------------------------\n"+v.toString());
                }


                s0 = merge(s0, v.toString());
                if (debug) {

                    log.info("MMMM- after merge -------------------------------\n"+s0);

//                    log.info(String.format("S0MMMMM merge %s,now %s", v, s0));
                }
            }
        } else if (Constants.S1.equals(key)) {
            if (s1 == null) {
                s1 = new MRStats();
            }
            for (Text v : values) {
                s1 = merge(s1, v.toString());
                if (debug) {
                    log.info(String.format("S1 merge %s,now %s", v, s1));
                }
            }
        } else {
            super.reduce(key, values, context);
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        if (s0 != null || s1 != null) {
            Configuration conf = context.getConfiguration();
            ConnectionPool pool = null;
            try {
                pool = ConnectionPoolBuilder.createConnectionPool(conf);
                report(conf, pool);
            } catch (Throwable e) {
                log.error("failed to report", e);
                if (debug) {
                    throw new IOException(e);
                }
            } finally {
                if (pool != null) {
                    pool.closeAllConnections();
                }
            }
            if(abort){
                throw new IOException(String.format("s0=%s\ns1=%s",s0,s1));
            }
        }
        super.cleanup(context);
    }

    private void report(Configuration conf, ConnectionPool pool) {
        MySqlMRStatis statis = new MySqlMRStatis();
        statis.setDayAndHour(day, hour);
        statis.init(conf, pool);
        statis.report(s0, s1);
    }
}
