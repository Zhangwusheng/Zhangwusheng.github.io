/**
 * Jan 29, 2015
 */
package com.aipai.bigdata.etl.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author lin
 *
 */
public final class Filter {
    private final Set<String> wlist;
    private final Set<String> blist;
    
    private final List<String> wstarts = new ArrayList<String>();
    private final List<String> bstarts = new ArrayList<String>();
    
    public Filter(Collection<String> w,Collection<String> b){
        this.wlist = new HashSet<String>(w.size()*4);
        this.blist = new HashSet<String>(b.size()*4);
        parse(w, wlist, wstarts);
        parse(b, blist, wstarts);
    }
    
    public boolean ignore(String str){
        if(!wlist.isEmpty() || !wstarts.isEmpty()){
            return !contains(wlist, wstarts, str);
        }
        return contains(blist, bstarts, str);
    }
    
    
    private boolean contains(Set<String> set,List<String>starts,String str){
        if (!set.isEmpty() && set.contains(str)) {
            return true;
        }
        for(String w:starts){
            if(str.startsWith(w)){
                return true;
            }
        }
        return false;
    }

    private static void parse(Collection<String> origs,Set<String> exact,List<String> starts){
        for(String orig:origs){
            if(orig.startsWith("@")){
                starts.add(orig.substring(1));
            }else{
                exact.add(orig);
            }
        }
    }
    
    @Override
    public String toString(){
        return String.format("wlist=%s,wstart=%s,blist=%s,bstarts=%s",wlist,wstarts,blist,bstarts);
    }
}
