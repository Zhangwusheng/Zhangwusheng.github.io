/**
 * May 30, 2013
 */
package com.aipai.bigdata.etl.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

//import com.hiido.live.common.utils.IOUtils;

/**
 * @author lin
 * 
 */
public final class ConnectionPool {
    private int coreSize = 1;
    private final List<Connection> conns = new LinkedList<Connection>();
    private JdbcConn jdbcConn;
    private int checkValidTimeout = 1; // sec

    public ConnectionPool() {
    }

    public ConnectionPool(JdbcConn jdbcConn) {
        this(jdbcConn, 1);
    }

    public ConnectionPool(JdbcConn jdbcConn, int coreSize) {
        this.jdbcConn = jdbcConn;
        this.coreSize = coreSize;
    }

    @Override
    public String toString(){
        return (jdbcConn==null?"null":jdbcConn)+"["+coreSize+"]";
    }
    private final Object sync = new Object();

    public Connection acquire() throws SQLException {
        synchronized (sync) {
            while (!conns.isEmpty()) {
                Connection r = conns.remove(0);
                if (r == null) {
                    continue;
                }
                try {
                    if (r.isValid(checkValidTimeout)) {
                        return r;
                    } else {
//                        IOUtils.closeIO(r);
                        IOUtils.close(r);
                    }
                } catch (SQLException ex) {
//                    IOUtils.closeIO(r);
                    IOUtils.close(r);
                }
            }
        }
        return jdbcConn.openConnection(true);
    }

    public void release(Connection conn, boolean err) {
        if (conn == null) {
            return;
        }
        if (!err) {
            synchronized (sync) {
                if (conns.size() < coreSize) {
                    conns.add(conn);
                    return;
                }
            }
        }
//        IOUtils.closeIO(conn);
        IOUtils.close(conn);
    }

    public void closeAllConnections() {
        synchronized (sync) {
            for (Connection c : this.conns) {
//                IOUtils.closeIO(c);
                IOUtils.close(c);
            }
        }
    }

    public int getCoreSize() {
        return coreSize;
    }

    public JdbcConn getJdbcConn() {
        return jdbcConn;
    }

    public int getCheckValidTimeout() {
        return checkValidTimeout;
    }

    public void setCheckValidTimeout(int checkValidTimeout) {
        this.checkValidTimeout = checkValidTimeout;
    }

    public void setJdbcConn(JdbcConn jdbcConn) {
        this.jdbcConn = jdbcConn;
    }

}
