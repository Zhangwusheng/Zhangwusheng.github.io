package com.aipai.bigdata.etl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import com.aipai.bigdata.etl.util.JdbcConn;
import com.aipai.bigdata.etl.util.IOUtils;

public class MysqlNotifier implements Notify {
    private static final Log log = LogFactory.getLog(MysqlNotifier.class);
    private static final String sql = " INSERT INTO mretlog.etl_notify (act,state,path,set_time) VALUES (?,?,?,?)";
    
    private JdbcConn jdbcConn;
    
    private List<Entry> list = new LinkedList<Entry>();

    private class Entry{
        String act;
        String path;
        long time;
        boolean success;
        
        public Entry(String act, String path, boolean success){
            this.act = act;
            this.path = path;
            this.time = System.currentTimeMillis();
            this.success = success;
        }
    }

    private void commitAndClose() {
        if(!list.isEmpty()){
            Connection conn = null;
            PreparedStatement statement = null;
            try{
                conn = jdbcConn.openConnection();
                statement = conn.prepareStatement(sql);
                for(Entry e : list){
                    statement.setString(1, e.act);
                    statement.setString(2, e.success ? "success" : "fault");
                    statement.setString(3, e.path);
                    statement.setTimestamp(4, new Timestamp(e.time));
                    statement.addBatch();
                }
                statement.executeBatch();
            } catch(Exception e){
                log.error("error in mysqlnotifier.", e);
            } finally{
                list.clear();
                IOUtils.close(statement);
                IOUtils.close(conn);
            }
            if(jdbcConn != null)
                jdbcConn.close();
        }
    }

    public JdbcConn getJdbcConn() {
        return jdbcConn;
    }

    public void setJdbcConn(JdbcConn jdbcConn) {
        this.jdbcConn = jdbcConn;
    }

    @Override
    public void init(Configuration conf) {
        if(jdbcConn == null){
            jdbcConn = new JdbcConn();
            jdbcConn.setUrl(conf.get("jdbc.url"));
            jdbcConn.setUsername(conf.get("jdbc.user"));
            jdbcConn.setPassword(conf.get("jdbc.password"));
        }
    }

    @Override
    public void notify(String act, String path, boolean success) {
        Entry e = new Entry(act, path, success);
        list.add(e);
    }

    @Override
    public void close() {
        commitAndClose();
    }

}
