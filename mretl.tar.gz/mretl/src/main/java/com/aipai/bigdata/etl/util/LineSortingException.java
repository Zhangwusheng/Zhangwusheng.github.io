package com.aipai.bigdata.etl.util;


/**
* @author jackcptdev<jackcptdev@gmail.com>
* @version Nov 17, 2014 11:00:00 AM
* 
*/
public class LineSortingException extends Exception {

    private static final long serialVersionUID = 1L;

    public LineSortingException() {

    }

    public LineSortingException(String msg) {
        super(msg);

    }

    public LineSortingException(Throwable t) {
        super(t);
    }

    public LineSortingException(String msg, Throwable t) {
        super(msg, t);
    }

}
