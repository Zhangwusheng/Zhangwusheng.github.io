package com.aipai.bigdata.etl.mr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import com.aipai.bigdata.etl.util.ConnectionPool;
import  com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.Stats;
import com.aipai.bigdata.etl.Statis;


public final class MySqlMRStatis implements Statis {
    protected static final String SQL_DEL_LIST = "delete from mretlog.mr_stat where typ=? and day = ? and hour=?";
    protected static final String SQL_DEL_DETAIL = "delete from mretlog.mr_detail_stat where typ=? and day = ? and hour=?";

    protected static final String SQL_I_LIST = "insert into mretlog.mr_stat  "
            + "(typ,day,hour,total_num,sucess_num,failed_num,ufailed_num,ignored_num) values (?,?,?,?,?,?,?,?)";

    private static final String SQL_I_DETAIL = "insert into mretlog.mr_detail_stat "
            + "(typ,day,hour,act,sucess_num,failed_num,ignored_num) values (?,?,?,?,?,?,?)";
    private static final Log log = LogFactory.getLog(MySqlMRStatis.class);

    private boolean unable = false;

    private ConnectionPool pool;

    private String day;
    private String hour;

    public void setDayAndHour(String day, String hour) {
        this.day = day;
        this.hour = hour;
    }

    @Override
    public void report(Stats stats) {
        throw new UnsupportedOperationException();
    }

    public void report(MRStats s0, MRStats s1) {
        if (unable) {
            log.info("report s0" + s0);
            log.info("report s1" + s1);
            return;
        }
        report(s0, 0);
        report(s1, 1);
    }

    private void report(MRStats s, int sn) {
        if (s == null) {
            log.info("report............. s = null");
            return;
        }
        log.info(String.format("#%d:report %s", sn, s));
        if (delete(sn)) {
            insert(sn, s);
        } else {
            log.error("failed to clean report for " + sn);
        }
    }

    private void insert(int sn, MRStats s) {
        Connection conn = null;
        boolean err = false;
        try {
            conn = pool.acquire();
            PreparedStatement pstmt = conn.prepareStatement(SQL_I_LIST);
            pstmt.setInt(1, sn);
            pstmt.setString(2, day);
            pstmt.setString(3, hour);
            pstmt.setLong(4, s.total());
            pstmt.setLong(5, s.getSucess());
            pstmt.setLong(6, s.getFailed());
            pstmt.setLong(7, s.getUnknowFailed());
            pstmt.setLong(8, s.getTotalIgnored());
            pstmt.execute();
            pstmt.close();

            pstmt = conn.prepareStatement(SQL_I_DETAIL);
            Map<String, SFI> m = s.sfi();
            for (Entry<String, SFI> e : m.entrySet()) {
                SFI sfi = e.getValue();
                pstmt.setInt(1, sn);
                pstmt.setString(2, day);
                pstmt.setString(3, hour);
                pstmt.setString(4, e.getKey());
                pstmt.setLong(5, sfi.sucess);
                pstmt.setLong(6, sfi.failed);
                pstmt.setLong(7, sfi.ignored);
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            pstmt.close();
        } catch (Throwable e) {
            err = true;
            log.error("failed to clean old statis", e);
        } finally {
            pool.release(conn, err);
        }
    }

    private boolean delete(int sn) {
        Connection conn = null;
        boolean err = false;
        try {
            conn = pool.acquire();
            PreparedStatement pstmt = conn.prepareStatement(SQL_DEL_LIST);
            pstmt.setInt(1, sn);
            pstmt.setString(2, day);
            pstmt.setString(3, hour);
            pstmt.execute();
            pstmt.close();

            pstmt = conn.prepareStatement(SQL_DEL_DETAIL);
            pstmt.setInt(1, sn);
            pstmt.setString(2, day);
            pstmt.setString(3, hour);
            pstmt.execute();
            pstmt.close();
        } catch (Throwable e) {
            err = true;
            log.error("failed to clean old statis", e);
        } finally {
            pool.release(conn, err);
        }
        return !err;
    }

    @Override
    public void init(Configuration conf, ConnectionPool pool) {
        this.unable = conf.getBoolean(Constants.ETL_M_PASS2R, false);
        this.pool = pool;
        log.info(String.format("unable=%b,pool=%s", unable, pool));
    }

    @Override
    public void close() {
    }

    @Override
    public void start() {
    }

}
