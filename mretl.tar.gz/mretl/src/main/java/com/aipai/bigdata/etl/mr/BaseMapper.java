/**
 * Jan 7, 2015
 */
package com.aipai.bigdata.etl.mr;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.NumCounter;
import com.aipai.bigdata.etl.Offset;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Mapper;
import com.aipai.bigdata.etl.util.Filter;
import com.aipai.bigdata.etl.util.JsonUtils;
//import com.hiido.live.tool.IpSeeker;
//import com.hiido.mretl.Constants;
//import com.hiido.mretl.mr.ylog.YlogMapper;
//import com.hiido.mretl.utils.Filter;
//import com.hiido.mretl.utils.IPUtils;
//import com.hiido.mretl.utils.JsonUtils;

/**
 * @author lin
 *
 */
public abstract class BaseMapper extends Mapper<Offset, Text, Text, Text> {
    protected static final Log log = LogFactory.getLog(BaseMapper.class);

    protected Text actText = new Text();
    protected Text lineText = new Text();

    protected final MRStats statis = new MRStats();
//    protected IpSeeker seeker;
    protected boolean debug;

    protected Filter filter;

    protected Map<String, NumCounter> parts;
    protected final StringBuilder sb = new StringBuilder(128);

    protected abstract String wlistKey();

    protected abstract String blistKey();

    protected abstract String actPartsKey();

    protected boolean pass2R;

    protected long incount;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        Configuration conf = context.getConfiguration();
//        IPUtils.init(conf);
//        seeker = IPUtils.getHMIPSeker();
        debug = conf.getBoolean(Constants.ETL_M_DUBUG, false);
        pass2R = conf.getBoolean(Constants.ETL_M_PASS2R, true);
        this.filter = new Filter(BaseMR.parseSet(conf, wlistKey()), BaseMR.parseSet(conf, blistKey()));
        Map<String, Integer> map = BaseMR.parseActParts(conf, actPartsKey());
        this.parts = new HashMap<String, NumCounter>(map.size() * 8);
        for (Entry<String, Integer> e : map.entrySet()) {
            this.parts.put(e.getKey(), new NumCounter(e.getValue()));
        }
        log.info(String.format("filter=%s,debug=%b,2r=%b", filter, debug, pass2R));
        log.info("parts:" + parts);
    }

    @Override
    public void map(Offset key, Text value, Context context) throws IOException, InterruptedException {
        if (debug) {
            log.info(String.format("key=%s,val=%s", key, value.toString()));
        }
        incount++;
        if (parse(key, value)) {
            context.write(actText, lineText);
        }
    }

    protected String act2Parts(String sact) {
        NumCounter nc = parts.get(sact);
        if (nc == null) {
            return sact;
        } else {
            int num = nc.next() - 1;
            if (num < 0) {
                return sact;
            } else {
                sb.setLength(0);
                sb.append(sact).append(Constants.PARTS_SPLIT).append(num);
                return sb.toString();
            }
        }
    }

    protected boolean ignored(String act) {

        return filter.ignore(act);
    }

    protected abstract boolean parse(Offset key, Text value);

    protected void passStats2Reduce(Context context) throws IOException, InterruptedException {
        String str = JsonUtils.pack(statis);
        context.write(Constants.S0, new Text(str));
    }

    @Override
    public void cleanup(Context context) throws IOException, InterruptedException {
        log.info(statis);

        log.info("pass2R="+pass2R);
        if (pass2R) {
            passStats2Reduce(context);
        }
        Counter c = context.getCounter("IN", "lines");
        c.increment(incount);
        log.info("total read line:"+incount);
        super.cleanup(context);
    }
}
