/**
 * Feb 9, 2015
 */
package com.aipai.bigdata.etl.mr;

/**
 * @author lin
 *
 */
public final class SFI {
    public long sucess;
    public long failed;
    public long ignored;
    
    public SFI(long s,long f){
        this.sucess = s;
        this.failed = f;
    }
    
    public SFI(){
    }
}
