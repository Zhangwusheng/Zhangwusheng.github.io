/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.mblog;

import com.aipai.bigdata.etl.util.SortingResult;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.Text;
import com.aipai.bigdata.etl.mr.BaseMapper;
import com.aipai.bigdata.etl.Offset;
import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.util.LineSorting;

//import com.hiido.etl.log.sorting.LineSorting;
//import com.hiido.etl.log.sorting.SortingResult;
//import com.hiido.mretl.Constants;
//import com.hiido.mretl.mr.BaseMapper;
//import com.hiido.mretl.mr.NumCounter;
//import com.hiido.mretl.mr.Offset;

/**
 * @author lin
 *
 */
public class MblogMapper extends BaseMapper {
    protected static final Log log = LogFactory.getLog(MblogMapper.class);

    protected boolean parse(Offset key, Text value) {
        SortingResult ret = null;
        final String min = key.getName();

        log.info("map key="+key+",value="+value.toString());
        try {

            ret = LineSorting.getActAndResultLine( value.toString());
            String sact = ret.getAct();
            String sline = ret.getLine();
            if (!ret.isError()) {
                if (ignored(sact)) {
                    statis.ignored(sact,1);
                    return false;
                }
                actText.set(act2Parts(sact));
                lineText.set(min + "," + sline);
                statis.sucess(sact, 1);
                return true;
            } else {
                if (sact == null) {
                    //unkonw act error
                    statis.addUnknowFailed(1);
                } else {
                    statis.failed(sact, 1);
                }
                if (debug) {
                    log.info("DEBUG:err in sorting", ret.getException());
                }
            }
        } catch (Throwable e) {
            statis.addUnknowFailed(1);
            if (debug) {
                log.info("DEBUG:err in parse", e);
            }
        }
        return false;
    }

    @Override
    protected String wlistKey() {
        return Constants.ETL_KEY_YLOG_WHITE_LIST;
    }

    @Override
    protected String blistKey() {
        return Constants.ETL_KEY_YLOG_BLACK_LIST;
    }

    @Override
    protected String actPartsKey() {
        return Constants.ETL_KEY_MBLOG_PARTS;
    }

}
