package com.aipai.bigdata.etl.util;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.OverlappingFileLockException;


public final class FileLock implements Closeable {
    private final File file;
    private final FileChannel channel;
    private java.nio.channels.FileLock flock;
    private final Object sync = new Object();

    public FileLock(File file) {
        this.file = file;
        try {
            file.getParentFile().mkdirs();
            file.createNewFile();
            this.channel = new RandomAccessFile(file, "rw").getChannel();
        } catch (IOException e) {
            throw new RuntimeException("failed to init FileLock for:" + file.getAbsolutePath(), e);
        }
    }

    public File file() {
        return file;
    }

    public void lock() {
        synchronized (sync) {
            try {
                flock = channel.lock();
            } catch (IOException e) {
                throw new RuntimeException("IOErr in lock file", e);
            }
        }
    }

    public boolean tryLock() {
        synchronized (sync) {
            try {
                flock = channel.tryLock();
                return flock != null;
            } catch (OverlappingFileLockException e) {
                return false;
            } catch (IOException e) {
                throw new RuntimeException("IOErr in try lock file", e);
            }
        }
    }

    public void unlock() {
        synchronized (sync) {
            if (flock != null)
                try {
                    flock.release();
                } catch (IOException e) {
                    throw new RuntimeException("IOErr in release file lock", e);
                }
        }
    }

    @Override
    public void close() {
        synchronized (sync) {
            try {
                unlock();
            } finally {
                IOUtils.close(channel);
            }
        }

    }
}
