/**
 * Jan 8, 2015
 */
package com.aipai.bigdata.etl.mr;

/**
 * @author lin
 *
 */
public final class LongWrapper {
    public long v;
    
    
    
    public LongWrapper(){
    }
    
    public LongWrapper(long v){
        this.v = v;
    }
    
    public long getV() {
        return v;
    }

    public void setV(long v) {
        this.v = v;
    }

    public LongWrapper copy(){
        return new LongWrapper(v);
    }
    @Override
    public String toString(){
        return String.valueOf(v);
    }
}
