/**
 * Jan 26, 2015
 */
package com.aipai.bigdata.etl.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author lin
 *
 */
public final class ConnectionPoolBuilder {

    public static ConnectionPool createConnectionPool(org.apache.hadoop.conf.Configuration conf){
        Map<String,String> map = new HashMap<String, String>();
        Iterator<Entry<String, String>> e = conf.iterator();
        while(e.hasNext()){
            Entry<String, String> one = e.next();
            map.put(one.getKey(), one.getValue());
        }
//        return ConnectionPoolFactory.createConnectionPool(new com.hiido.live.common.Configuration(map));
          return ConnectionPoolFactory.createConnectionPool(new com.aipai.bigdata.etl.util.Configuration(map));
    }
}
