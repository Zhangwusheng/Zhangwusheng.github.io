/**
 * Dec 30, 2014
 */
package com.aipai.bigdata.etl;

/**
 * @author lin
 *
 */
public final class NumCounter {
    public final int max;
    private int cur;

    public NumCounter(int max) {
        this.max = max;
    }

    public int next() {
        int get = cur++;
        if (cur == max) {
            cur = 0;
        }
        return get;
    }

    @Override
    public String toString() {
        return max + "-" + cur;
    }
}
