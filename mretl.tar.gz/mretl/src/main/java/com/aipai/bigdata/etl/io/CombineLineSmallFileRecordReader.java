/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.io;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
//import org.apache.hadoop.io.compress.CodecPool;
//import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
//import org.apache.hadoop.mapreduce.lib.output.MyLineRecordWriter;
import org.apache.hadoop.mapreduce.lib.input.CombineFileSplit;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;
import org.mortbay.log.Log;

import com.aipai.bigdata.etl.Offset;

/**
 * @author lin
 *
 */
public final class CombineLineSmallFileRecordReader extends RecordReader<Offset, Text> {
    public static final String M_INPUT_FILE = "mapreduce.map.input.file";
    public static final String M_INPUT_PATH = "mapreduce.map.input.length";
    public static final String M_INPUT_START = "mapreduce.map.input.start";

    protected CombineFileSplit split;
    protected FileSystem fs;
    protected TaskAttemptContext context;

    protected int idx;
    protected long progress;
    protected LineRecordReader curReader;
    protected Offset offset = new Offset();
    protected boolean inited;
    protected int fileCount;

    @Override
    public void initialize(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
        if (inited) {
            throw new IOException("reader has inited");
        }
        this.split = (CombineFileSplit) split;
        this.context = context;
        inited = true;

        Counter c = context.getCounter("IN", "splits");
        c.increment(this.split.getNumPaths());
    }

    @Override
    public boolean nextKeyValue() throws IOException, InterruptedException {
        while ((curReader == null) || !curReader.nextKeyValue()) {
            if (!initNextRecordReader()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Offset getCurrentKey() throws IOException, InterruptedException {
        LongWritable key = curReader.getCurrentKey();
        offset.setOffset(key.get());
        return offset;
    }

    @Override
    public Text getCurrentValue() throws IOException, InterruptedException {
        return curReader.getCurrentValue();
    }

    @Override
    public float getProgress() throws IOException, InterruptedException {
        long subprogress = 0; // bytes processed in current split
        if (null != curReader) {
            // idx is always one past the current subsplit's true index.
            subprogress = (long) (curReader.getProgress() * split.getLength(idx - 1));
        }
        return Math.min(1.0f, (progress + subprogress) / (float) (split.getLength()));
    }

    @Override
    public void close() throws IOException {
        if (curReader != null) {
            curReader.close();
            curReader = null;
        }
        if(fileCount!=split.getNumPaths()){
            throw new IOException(String.format("splitNum=%d,but just read %d", fileCount,split.getNumPaths()));
        }
    }

    private void initLineRecordReader(LineRecordReader reader, FileSplit fsplit, String fname) throws IOException {
        reader.initialize(fsplit, context);
        offset.setFileName(fname);
    }

    protected boolean initNextRecordReader() throws IOException {

        if (curReader != null) {
            curReader.close();
            curReader = null;
            if (idx > 0) {
                progress += split.getLength(idx - 1); // done processing so far
            }
        }

        // if all chunks have been processed, nothing more to do.
        if (idx == split.getNumPaths()) {
            return false;
        }

        context.progress();

        // get a record reader for the idx-th chunk
        try {
            Configuration conf = context.getConfiguration();
            // setup some helper config variables.
            final Path file = split.getPath(idx);
            final long len = split.getLength(idx);
            conf.set(M_INPUT_FILE, file.toString());
            conf.setLong(M_INPUT_START, 0);
            conf.setLong(M_INPUT_PATH, len);

            curReader = new CountReader(file.getName());
            initLineRecordReader(curReader, new FileSplit(file, 0, len, null), file.getName());
            Log.info(String.format("open reader for [%d]:%s", len, file));
            Counter c = context.getCounter("IN", "files");
            fileCount++;
            c.increment(1);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        idx++;
        return true;
    }

    private static final class CountReader extends LineRecordReader {
        long lineCount;
        final String file;
        CountReader(String file){
            this.file = file;
        }
        public synchronized void close() throws IOException {
            super.close();
            Log.info(String.format("%d lines in %s",lineCount,file));
          }
        @Override
        public boolean nextKeyValue() throws IOException {
            boolean has = super.nextKeyValue();
            if(has){
                lineCount++;
            }
            return has;
        }

    }

}
