package com.aipai.bigdata.etl.util;

//import com.hiido.live.common.utils.StringUtils;
//import com.hiido.live.tool.HiidoMoneyIPSeeker;
//import com.hiido.live.tool.IPInfo;
//import com.hiido.live.tool.IpSeeker;

//import java.io.File;
//import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;
//import java.net.URLEncoder;
import com.aipai.bigdata.etl.Constants;
import com.aipai.bigdata.etl.util.StringUtils;
import com.aipai.bigdata.etl.util.JsonUtils;
import com.aipai.bigdata.etl.util.ConnectionPool;
import com.aipai.bigdata.etl.util.ConnectionPoolBuilder;
/**
* @author jackcptdev<jackcptdev@gmail.com>
* @version Nov 17, 2014 10:46:42 AM
* 
*/
public class LineSorting {

    public static SortingResult getActAndResultLine( String line) {
        try {
            return getResultInfo( line);
        } catch (Throwable t) {
            System.out.printf("!!"+t.toString());
            SortingResult r = new SortingResult(true, null, line, t);
            return r;
        }
    }

//    private static String getUidFromKey(String key) {
//        if (key.length() < 8) {
//            return null;
//        }
//        String key_val_part = key.substring(key.length() - 8);
//        long uid = Long.parseLong(key_val_part, 16);
//        return String.valueOf(uid);
//    }

    private static SortingResult getResultInfo( String line) {
        String[] ipAndContentAndRefer = null;
        try {
            ipAndContentAndRefer = parseRecord(line);
        } catch (Throwable e) {
            SortingResult r = new SortingResult(true, null, line, e);
            return r;
        }

        String ip = ipAndContentAndRefer[0];
        String strResultInfo = ipAndContentAndRefer[1];
        String strRefer = ipAndContentAndRefer[2];
        int actidx = strResultInfo.indexOf("&",0);
        String actVal = strResultInfo.substring(7,actidx);

//        StringBuilder tmpBuilder = new StringBuilder(strResultInfo.length() + 1);
//        tmpBuilder.append(strResultInfo);
//        tmpBuilder.append("&");
//
//        String strResultInfo2 = tmpBuilder.toString();
//
//        String act_val = getGapString2(strResultInfo2, "act=", "&", ",", 63);
//
//        StringBuilder strIPInfo = null;
//
//        if (StringUtils.isEmpty(act_val)) {
//            SortingResult r = new SortingResult(true, null, line, new Exception("act_val is emptry"));
//            return r;
//        }
//
//        if (!isActValue(act_val)) {
//            SortingResult r = new SortingResult(true, act_val, line, new Exception("Wrong act_val :" + act_val));
//            return r;
//        }
//
//        if (act_val.startsWith("web")) {
//            StringBuilder strIPInfoBuilder = getIPInfo(ipSeeker, ip, true);
//            if ("web".equals(act_val)) {
//                strIPInfoBuilder.append("&lp=");
//                strIPInfoBuilder.append(strRefer);
//            }
//            strIPInfo = strIPInfoBuilder;
//        } else if (act_val.startsWith("proxy") || act_val.startsWith("mbsdk")) {
//            StringBuilder strIPInfoBuilder = getIPInfo(ipSeeker, ip, true);
//            strIPInfo = strIPInfoBuilder;
//        } else {
//            try {
//                check_no_web_act(strResultInfo2, act_val);
//            } catch (Throwable e) {
//                SortingResult r = new SortingResult(true, act_val, line, e);
//                return r;
//            }
//            StringBuilder strIPInfoBuilder = getIPInfo(ipSeeker, ip, false);
//            strIPInfo = strIPInfoBuilder;
//        }
//        String ans = String.format("%s%s", strResultInfo2, strIPInfo.toString());
        SortingResult r = new SortingResult(false, actVal, strResultInfo, null);
        return r;
    }

//    private static void check_no_web_act(String content, String act_val) throws LineSortingException {
//
//        String time_val = getGapString2(content, "&time=", "&", ",", 127);
//        String key_val = getGapString2(content, "&key=", "&", ",", 127);
//        String uid_val = getGapString2(content, "&uid=", "&", ",", 127);
//
//        if (StringUtils.isEmpty(time_val)) {
//            throw new LineSortingException("ERR_REC_NO_TIME");
//        }
//
//        if (StringUtils.isEmpty(key_val)) {
//            throw new LineSortingException("ERR_REC_NO_KEY");
//        }
//
//        if (StringUtils.isEmpty(uid_val)) {
//            //from key
//            uid_val = getUidFromKey(key_val);
//        }
//
//        String strHiido = String.format("%s%s%s", act_val, time_val, "HiidoYYSystem");
//        String md5Str = StringUtils.md5(strHiido);
//        if (!key_val.equals(md5Str)) {
//            throw new LineSortingException("ERR_REC_MD5_EXCEPT");
//        }
//    }


//
//    private static String getGapString2(String src, String begin, String end, String orEnd, int len) {
//        String r = getGapString(src, begin, end, len);
//        if (r == null) {
//            r = getGapString(src, begin, orEnd, len);
//        }
//        return r;
//    }
//
//    private static String getGapString(String src, String begin, String end, int len) {
//        if (StringUtils.isEmpty(src) || StringUtils.isEmpty(begin) || StringUtils.isEmpty(end)) {
//            return null;
//        }
//
//        int p1 = src.indexOf(begin);
//        if (p1 < 0) {
//            return null;
//        }
//
//        int startp = p1 + begin.length();
//        int p = src.indexOf(end, startp);
//        if (p < 0) {
//            return null;
//        }
//        int l_ilen = p - startp;
//        int rlen = l_ilen < len ? l_ilen : len - 1;
//        String str = src.substring(startp, startp + rlen);
//        return str;
//    }

//    private static boolean isActChar(char c) {
//        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isActValue(String act) {
//        if (StringUtils.isEmpty(act)) {
//            return false;
//        }
//        for (int i = 0; i < act.length(); i++) {
//            char c = act.charAt(i);
//            if (!isActChar(c)) {
//                return false;
//            }
//        }
//        return true;
//    }

    private static String[] parseRecord(String line) throws LineSortingException {
        if (line == null) {
            throw new LineSortingException("line is null");
        }

        if (StringUtils.isEmpty(line)) {
            throw new LineSortingException("line is empty");
        }

        line = line.trim();
        int firstComma = line.indexOf(',');
        if (firstComma == -1) {
            throw new LineSortingException("ERR_REC_COLNUM_EXPECT");
        }

        String ip = line.substring(0, firstComma);
        int p_act_begin = firstComma + 3;

//        int str_200_00_304_00 = line.indexOf(",200,-,");
//        if (str_200_00_304_00 < 0) {
//            str_200_00_304_00 = line.indexOf(",304,-,");
//        }
//
//        if (str_200_00_304_00 < 0) {
//            throw new LineSortingException("ERR_REC_FORMAT");
//        }

//        int p_act_begin = str_200_00_304_00 + 7;

        String line_act_start = line.substring(p_act_begin);
        int p_act_end = line_act_start.indexOf(',');

        if (p_act_end < 0 || p_act_end >= (line_act_start.length() - 1)) {
            throw new LineSortingException("ERR_REC_COLNUM_EXPECT");
        }

        int p1 = 0;
        int p = 0;
        String tmpLine = line_act_start;
        String actContent = line_act_start.substring(0,p_act_end);
        String strRefer = "NoParse";
//        while ((p1 + 1 < tmpLine.length()) && (p1 = tmpLine.indexOf(',', p1 + 1)) > 0) {
//            if (p >= tmpLine.length()) {
//                break;
//            }
//            String ln = tmpLine.substring(p);
//
//            if (ln.indexOf("&time=") > 0 || ln.indexOf("&st=") > 0 || ln.indexOf("&key=") > 0 || ln.indexOf("&uid=") > 0 || ln.indexOf("&ui=") > 0) {
//                p_act_end = p1;
//                p = p1 + 1;
//                continue;
//            }
//            break;
//        }

//        String actContent = tmpLine.substring(0, p_act_end);
//        String strRefer = tmpLine.substring(p_act_end + 1);
//        strRefer = URLEncoder.encode(strRefer);
        return new String[] { ip, actContent, strRefer };
    }

    public static void main(String[] args) throws LineSortingException, IOException {
        String line = "14.18.236.76,-,action=mbclick&hdr=UgYxMjNhYmOiAQnosYzosYbojZqSAw84NjExMzUwMjE0Njk0MzTiAwQxLjAzsgQEMi4wNIIFB0Fu%0AZHJvaWTSBQIxOaIGBU1laXp18gYEMi4wMQ%3D%3D%0A&logid=c474b560a2bd4e9281c12cef6fe5e821&clitime=1435302052931&data=SGNSC3VzZXJpZHh4MTIzWg0KCURlbW9DbGljaxAB%0A,200,43,\"-\",\"Apache-HttpClient/UNAVAILABLE (java 1.4)\",\"-\"";

        SortingResult v = getActAndResultLine( line);
        System.out.println(v);


        Map<String,String> map = new HashMap<String, String>();
        map.put(Constants.JDBC_USER,"mretlog");
        map.put(Constants.JDBC_PASSWORD,"mretlog@aipai");
        map.put(Constants.JDBC_URL,"jdbc:mysql://192.168.1.204:3306/mretlog?useUnicode=true&characterEncoding=utf-8&autoReconnect=true");

        com.aipai.bigdata.etl.util.Configuration conf = new com.aipai.bigdata.etl.util.Configuration(map);
        ConnectionPool pool = ConnectionPoolFactory.createConnectionPool(conf);

        Connection conn = null;
        boolean err = false;
        try {
            String sql = " INSERT INTO mretlog.etl_notify (act,state,path) VALUES (?,?,?)";

            conn = pool.acquire();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "sn");
            pstmt.setString(2, "day");
            pstmt.setString(3, "hour");
            pstmt.execute();
            pstmt.close();

        } catch (Throwable e) {
            err = true;
            System.out.printf("E:"+e);
//            log.error("failed to clean old statis", e);
        } finally {
            pool.release(conn, err);
        }
    }
}
