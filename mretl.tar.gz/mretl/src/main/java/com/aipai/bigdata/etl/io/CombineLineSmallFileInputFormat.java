/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.io;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import com.aipai.bigdata.etl.Offset;

/**
 * @author lin
 *
 */
public final class CombineLineSmallFileInputFormat extends CombineSmallFileInputFormat<Offset, Text> {

    @Override
    public RecordReader<Offset, Text> createRecordReader(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
        return new CombineLineSmallFileRecordReader(); 
    }
}
