/**
 * Dec 12, 2014
 */
package com.aipai.bigdata.etl.mr;

/**
 * @author lin
 *
 */
public final class SucessAndFailed {
    private long sucess;
    private long failed;

    public SucessAndFailed() {
    }

    public SucessAndFailed(long sucess, long failed) {
        this.sucess = sucess;
        this.failed = failed;
    }

    public SucessAndFailed copy() {
        return new SucessAndFailed(sucess, failed);
    }

    public long total() {
        return failed + sucess;
    }

    public void addSucess(long s) {
        sucess += s;
    }

    public void addFailed(long f) {
        failed += f;
    }
    
    public void setSucess(long sucess) {
        this.sucess = sucess;
    }

    public void setFailed(long failed) {
        this.failed = failed;
    }

    public long getSucess() {
        return sucess;
    }

    public long getFailed() {
        return failed;
    }

    @Override
    public String toString() {
        return String.format("%d/%d=%d", sucess, total(), sucess * 10000
                / total());
    }
}
