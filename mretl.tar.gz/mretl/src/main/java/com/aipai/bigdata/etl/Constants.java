/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl;

import org.apache.hadoop.io.Text;
import java.nio.charset.Charset;
/**
 * @author lin
 *
 */
public final class Constants {
    private Constants(){
    }
    
    public static final Text S0 = new Text("_s0");
    public static final Text S1 = new Text("_s1");
    
    public static final String PARTS_SPLIT = "!";


    public static final String ETL_KEY_MBLOG_IN_BASE_PATH = "etl.mblob.in.path";
    public static final String DEF_MBLOG_IN_BASE_PATH = "/logs/raw";


    public static final String ETL_M_DUBUG = "etl.m.debug";
    public static final String ETL_R_DUBUG = "etl.r.debug";
    public static final String ETL_R_ABORT_REPORT = "etl.r.abort.report";
    public static final String ETL_M_PASS2R = "etl.m.pass2r";
    public static final String ETL_KEY_CLEAN_TMP_OUT="etl.clean.tmp.out";
    
    public static final String ETL_KEY_YLOG_WHITE_LIST = "etl.ylog.white.list";
    public static final String ETL_KEY_YLOG_BLACK_LIST = "etl.ylog.black.list";
    
    public static final String ETL_KEY_TLOG_WHITE_LIST = "etl.tlog.white.list";
    public static final String ETL_KEY_TLOG_BLACK_LIST = "etl.tlog.black.list";

    public static final String ETL_KEY_TLOG_SORTING_WHITE_LIST = "etl.tlog.sorting.white.list";
    public static final String ETL_KEY_TLOG_SORTING_BLACK_LIST = "etl.tlog.sorting.black.list";
    
    public static final String ETL_KEY_MBLOG_MAPPING = "etl.mblog.mapping";
    public static final String ETL_KEY_TLOG_MAPPING = "etl.tlog.mapping";
    
    public static final String ETL_KEY_TLOG_IN_BASE_PATH = "etl.tlog.in.path";
    public static final String DEF_CLASSIFY_TLOG_IN_BASE_PATH = "/classify_in/tlog";
    
    public static final String ETL_KEY_TLOG_OUT_BASE_PATH = "etl.tlog.out.path";
    public static final String DEF_CLASSIFY_TLOG_OUT_BASE_PATH = "/classify_out/tlog";
    
    
    public static final String ETL_KEY_MBLOG_INPUT_BASE_PATH = "etl.mblog.input.path";
    public static final String DEF_CLASSIFY_MBLOG_INPUT_BASE_PATH = "/logs/raw";
    
    public static final String ETL_KEY_MBLOG_OUTPUT_BASE_PATH = "etl.mblog.out.path";
    public static final String DEF_CLASSIFY_MBLOG_OUTPUT_BASE_PATH = "/logs/mbloggroup";
    
    public static final String ETL_KEY_RESULT_BASE_PATH = "etl.result.path";
    public static final String DEF_ETL_RESULT_BASE_PATH = "/mrlogs";
    
    public static final String ETL_KEY_HOUR = "etl.hour";
    public static final String ETL_KEY_DAY = "etl.day";
    public static final String ETL_KEY_OVERWRITE = "etl.overwrite";
    public static final String ETL_KEY_NOTIFY = "etl.notify";
    public static final String ETL_KEY_NOTIFY_NO_OVERWRITE = "etl.notify.no.overwrite";
    
    
    public static final String ETL_KEY_YLOG_REDUCE_NUM = "etl.ylog.red.num";
    public static final String ETL_KEY_TLOG_REDUCE_NUM = "etl.tlog.red.num";
    
    public static final String ETL_KEY_LOCK = "etl.lock";
    public static final String ETL_KEY_SKIP_MARK = "etl.skip.mark";
    
    public static final String ETL_KEY_MBLOG_PARTS="etl.mblog.parts";
    public static final String ETL_KEY_TLOG_PARTS="etl.tlog.parts";
    
    public static final String ETL_KEY_TLOG_SORTING_ACTS = "etl.tlog.sorting.acts";
    public static final String ETL_KEY_TLOG_SORTING_PREFIX = "etl.tlog.sorting.prefix";
    public static final String DEF_ETL_TLOG_SORTING_PREFIX = "post_";
    public static final String ETL_KEY_TLOG_NEW_CLASSLOADER="etl.tlog.new.classloader";
    public static final String ETL_KEY_TLOG_RSA_JARS = "etl.tlog.ras.jars";
    
    public static final String ETL_KEY_LOAD_SCANQ_SIZE = "etl.load.scanq.size";
    public static final String ETL_KEY_LOAD_SCAN_INTERVAL_S = "etl.load.scan.interval.s";
    public static final String ETL_KEY_LOAD_SCAN_TIMEOUT_S = "etl.load.scan.timeout.s";
    public static final String ETL_KEY_LOAD_SCAN_MAX_PENDING = "etl.load.scan.max.pending";
    public static final String ETL_KEY_LOAD_SCAN_MAX_COMMIT_TRY = "etl.load.scan.max.commit.try";
    public static final String ETL_KEY_LOAD_SCAN_PATHS = "etl.load.scan.paths";
    public static final String ETL_KEY_LOAD_SCAN_INSTANCE = "etl.load.scan.instance";
    
    public static final String ETL_KEY_LOAD_BACKOFF_MS = "etl.load.backoff.ms";
    public static final String ETL_KEY_LOAD_BACKOFF_TRY ="etl.load.backoff.try";
    public static final String ETL_KEY_LOAD_MAX_BACKOFF_SIZE = "etl.load.max.backoff.size";
    public static final String ETL_KEY_LOAD_WORKER_NUM = "etl.load.worker.num";
    public static final String ETL_KEY_LOAD_UNABLE = "etl.load.unable";
    
    public static final String ETL_KEY_LOAD_HDFS_BASE_PATH = "etl.load.hdfs.base.path";
    public static final String ETL_KEY_LOAD_HDFS_TMP_PATH = "etl.load.hdfs.tmp.path";
    
    public static final String ETL_KEY_LOAD_HISTORY_LAST_MINUTE = "etl.load.history.last.minute";
    public static final String ETL_KEY_LOAD_HISTORY_MAX_MINUTE = "etl.load.history.max.minute";
    public static final String ETL_KEY_LOAD_HISTORY_CHECK_BEFORE_MINUTES = "etl.load.history.check.before.minutes";
    public static final String ETL_KEY_LOAD_MAX_DAY = "etl.load.history.max.day";
    public static final String ETL_KEY_LOAD_FHISTORY_MARK_PATH="etl.load.fhistory.mark.path";

    public static final String JDBC_USER = "jdbc.user";
    public static final String JDBC_PASSWORD = "jdbc.password";
    public static final String JDBC_URL = "jdbc.url";
    public static final String JDBC_POOL_SIZE = "jdbc.pool.size";

    public static final Charset UTF8 = Charset.forName("UTF-8");
}
