/**
 * Dec 11, 2014
 */
package com.aipai.bigdata.etl.io;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.lib.input.CombineFileSplit;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.net.NetworkTopology;

/**
 * @author lin
 *
 */
public abstract class CombineSmallFileInputFormat<K, V> extends FileInputFormat<K, V> {
    public static final String MAX_FILE_NUM = "mr.input.mf.max.num";
    public static final String MAX_FILE_MBYTES = "mr.input.mf.max.mbytes";

    protected static final Log log = LogFactory.getLog(CombineSmallFileInputFormat.class);

    protected int maxFileNum;
    protected long maxFileMBytes;

    private CombineFileSplit creatSplit(FileSystem fs, List<FileStatus> list) throws IOException {
        Path[] p = new Path[list.size()];
        long[] l = new long[list.size()];
        long[] starts = new long[list.size()];
        int i = 0;
        Set<String> locations = new HashSet<String>();
        for (FileStatus s : list) {
            p[i] = s.getPath();
            l[i] = s.getLen();
            starts[i] = 0;
            BlockLocation[] blkLocations = fs.getFileBlockLocations(s, 0, s.getLen());
            if (blkLocations != null && blkLocations.length >= 1) {
                locations.addAll(Arrays.asList(blkLocations[0].getHosts()));
            }

            i++;
        }
        return new CombineFileSplit(p, starts, l, (String[]) locations.toArray(new String[locations.size()]));
    }

    @Override
    public List<InputSplit> getSplits(JobContext job) throws IOException {
        Configuration conf = job.getConfiguration();
        final int maxfn = maxFileNum != 0 ? maxFileNum : conf.getInt(MAX_FILE_NUM, 1000);
        final long maxfb = (maxFileMBytes != 0 ? maxFileMBytes : conf.getInt(MAX_FILE_MBYTES, 1024)) * 1024L * 1024L;
        log.info(String.format("maxFileNum=%d,maxFileMBytes=%d", maxfn, maxfb / 1024 / 1024));
        // all the files in input set
        List<FileStatus> stats = listStatus(job);
        if (stats == null || stats.isEmpty()) {
            log.warn("no children in input path");
            return Collections.EMPTY_LIST;
        }
        log.info("children files:" + stats.size());
        List<InputSplit> splits = new ArrayList<InputSplit>();

        List<FileStatus> part = new LinkedList<FileStatus>();
        FileSystem fs = FileSystem.get(conf);
        long totalSize = 0;
        for (FileStatus s : stats) {
            if (s.isDir()) {
                log.warn("skip,not a file:" + s.getPath());
                continue;
            }
            if (totalSize >= maxfb || part.size() >= maxfn) {
                splits.add(creatSplit(fs, part));
                part.clear();
                totalSize = 0;
            }
            part.add(s);
            totalSize += s.getLen();
        }
        if (!part.isEmpty()) {
            splits.add(creatSplit(fs, part));
        }
        log.info(String.format("input splits=%d:%s", splits.size(), splits));
        return splits;
    }

    @Override
    protected boolean isSplitable(JobContext context, Path file) {
        return false;
    }

}
