package com.aipai.bigdata.etl.util;

/**
* @author jackcptdev<jackcptdev@gmail.com>
* @version Dec 15, 2014 2:35:03 PM
* 
*/
public class SortingResult {

    private final boolean error;
    private final String act;
    private final String line;
    private final Throwable exception;

    public SortingResult(boolean error, String act, String line, Throwable exception) {
        this.error = error;
        this.act = act;
        this.line = line;
        this.exception = exception;
    }

    public Throwable getException() {
        return exception;
    }

    public boolean isError() {
        return error;
    }

    public String getAct() {
        return act;
    }

    public String getLine() {
        return line;
    }

    @Override
    public String toString() {
        StringBuffer b = new StringBuffer();
        b.append(" { error : ");
        b.append(error);
        b.append(" , act : ");
        b.append(act);
        b.append(" , line : ");
        b.append(line);
        b.append(" } ");
        return b.toString();
    }

}
