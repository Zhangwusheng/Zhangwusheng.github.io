/**
 * Dec 12, 2014
 */
package com.aipai.bigdata.etl.io;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
//import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;
import org.apache.hadoop.mapreduce.lib.output.FileOutputCommitter;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
//import org.apache.hadoop.mapreduce.lib.output.MyLineRecordWriter;
import org.apache.hadoop.mapreduce.lib.output.MyLineRecordWriter;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.ReflectionUtils;
import com.aipai.bigdata.etl.util.IOUtils;


/**
 * @author lin
 *
 */
public final class KeyAsPathLineFileoutputFormat extends FileOutputFormat<Text, Text> {
    public static String SEPERATOR = "mapreduce.output.textoutputformat.separator";
    private static final Log log = LogFactory.getLog(CombineSmallFileInputFormat.class);

    @Override
    public RecordWriter<Text, Text> getRecordWriter(TaskAttemptContext job) throws IOException, InterruptedException {
        return new MulitLineRecordWriter(job);
    }

    private Path getWorkPath(TaskAttemptContext context) throws IOException {
        FileOutputCommitter committer = (FileOutputCommitter) getOutputCommitter(context);
        return committer.getWorkPath();
    }

    private final class MulitLineRecordWriter extends RecordWriter<Text, Text> {
        final TaskAttemptContext job;
        final Path workPath;
        final Map<Text, MyLineRecordWriter<Text, Text>> writers = new HashMap<Text, MyLineRecordWriter<Text, Text>>(1024);

        MulitLineRecordWriter(TaskAttemptContext context) throws IOException {
            this.job = context;
            this.workPath = getWorkPath(context);
        }

        @Override
        public void write(Text key, Text value) throws IOException, InterruptedException {
               MyLineRecordWriter<Text, Text> w = getOrCreateKeyWriter(key);
               w.write(null, value);

        }

        @Override
        public void close(TaskAttemptContext context) throws IOException, InterruptedException {
            IOException err = null;
            for (Entry<Text, MyLineRecordWriter<Text, Text>> e : writers.entrySet()) {
                Text t = e.getKey();
                MyLineRecordWriter<Text, Text> w = e.getValue();
                try {
                    w.close(context);
                } catch (IOException ioe) {
                    err = ioe;
                    log.error("err in close file for " + t.toString(), ioe);
                }
            }
            if (err != null) {
                throw err;
            }

        }

        private MyLineRecordWriter<Text,Text> getOrCreateKeyWriter(Text key) throws IOException {
            MyLineRecordWriter<Text, Text> writer = writers.get(key);
            if (writer == null) {
                CompressionCodec codec = null;
                String extension = "";
                if (FileOutputFormat.getCompressOutput(job)) {
                    Class<? extends CompressionCodec> codecClass = getOutputCompressorClass(job, GzipCodec.class);
                    codec = (CompressionCodec) ReflectionUtils.newInstance(codecClass, job.getConfiguration());
                    extension = codec.getDefaultExtension();
                }
                Path file = new Path(workPath, key + extension);
                FileSystem fs = file.getFileSystem(job.getConfiguration());
                String keyValueSeparator = job.getConfiguration().get(SEPERATOR, "\t");
                DataOutputStream out = fs.create(file);
                log.info("create writer for "+file);
                try {
                    if (codec != null) {
                        out = new DataOutputStream(codec.createOutputStream(out));
                    }
                } catch (IOException e) {
                    IOUtils.close(out);
                    throw e;
                }
                writer = new MyLineRecordWriter<Text, Text>(out, keyValueSeparator);
                writers.put(new Text(key), writer);
            }
            return writer;
        }

    }

}
